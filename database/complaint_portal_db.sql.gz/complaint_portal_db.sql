-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 19, 2026 at 10:03 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `complaint_portal_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Hostel', '2026-08-11 04:02:42', '2026-08-11 04:02:42'),
(2, 'Academic', '2026-08-11 04:02:42', '2026-08-11 04:02:42'),
(3, 'Sports', '2026-08-11 04:02:42', '2026-08-11 04:02:42'),
(4, 'Campus Services', '2026-08-11 04:02:42', '2026-08-11 04:02:42'),
(5, 'Transport', '2026-08-11 04:02:42', '2026-08-11 04:02:42'),
(6, 'Medical', '2026-08-11 04:02:42', '2026-08-11 04:02:42'),
(7, 'Fee & Accounts', '2026-08-11 04:02:42', '2026-08-11 04:02:42'),
(8, 'Hostel Food', '2026-08-11 04:02:42', '2026-08-11 04:02:42'),
(9, 'Others', '2026-08-11 04:02:42', '2026-08-11 04:02:42');

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE `complaints` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ticket_number` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `sub_category_id` bigint(20) UNSIGNED DEFAULT NULL,
  `location` text DEFAULT NULL,
  `description` text NOT NULL,
  `complainant` varchar(255) DEFAULT NULL,
  `status` enum('pending','in_progress','resolved','closed') NOT NULL DEFAULT 'pending',
  `assigned_to` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `complaints`
--

INSERT INTO `complaints` (`id`, `ticket_number`, `user_id`, `category_id`, `sub_category_id`, `location`, `description`, `complainant`, `status`, `assigned_to`, `created_at`, `updated_at`) VALUES
(1, 'TCK-94AIFW', 4, 1, 3, 'Drona Hotel 2nd Floor Room Number 25', 'Just Test Details here.', 'Day Scholar Student', 'in_progress', 7, '2026-08-18 22:58:36', '2026-08-18 22:59:52'),
(2, 'TCK-JTGYCK', 7, 2, 9, 'Test location here', 'gfhfgh thhfghf ghfghfgh', 'Staff/employee', 'pending', NULL, '2026-08-18 23:12:50', '2026-08-18 23:12:50');

-- --------------------------------------------------------

--
-- Table structure for table `employee_profiles`
--

CREATE TABLE `employee_profiles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `employee_code` varchar(255) NOT NULL,
  `department` varchar(255) DEFAULT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employee_profiles`
--

INSERT INTO `employee_profiles` (`id`, `user_id`, `phone_number`, `employee_code`, `department`, `designation`, `created_at`, `updated_at`) VALUES
(1, 6, '123456789', 'J2277', 'Digital', 'Assistant Director', '2026-08-12 00:13:03', '2026-08-12 00:13:03'),
(2, 7, '987654321', 'J5454', 'Digital', 'General Manager', '2026-08-12 00:13:03', '2026-08-12 00:13:03');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2026_08_11_071513_create_categories_table', 1),
(5, '2026_08_11_071525_create_sub_categories_table', 1),
(6, '2026_08_11_071533_create_complaints_table', 1),
(7, '2026_08_11_092732_create_student_profiles_table', 1),
(8, '2026_08_11_092739_create_employee_profiles_table', 1),
(9, '2026_08_12_072338_create_verification_codes_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('2ZTmrRg4pWgGjhHKQ6P1kCwdTtg45I9pIsHqlZhm', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoib0g2R2JFZzRVVVlJS0ZXYVZMblZVMUV2VmIwQ2s2QmcwSUd0ZU9DYiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NzA6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC8ud2VsbC1rbm93bi9hcHBzcGVjaWZpYy9jb20uY2hyb21lLmRldnRvb2xzLmpzb24iO319', 1787126552),
('TUb1KCFwxVOGczw5utoFqPZgx0bfb6xnsSufbRA1', 7, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', 'YTo1OntzOjY6Il90b2tlbiI7czo0MDoiWXY4MkttakJjazI3TEl0ZTdxbENEMFJGaTJOUWxLeGRqVm5JTjJQUSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDA6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9lbXBsb3llZS9kYXNoYm9hcmQiO31zOjE2OiJhdXRoX2xvZ2luX2VtYWlsIjtzOjI4OiJkZ20uZGlnaXRhbEBjZ2N1bml2ZXJzaXR5LmluIjtzOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aTo3O30=', 1787126246);

-- --------------------------------------------------------

--
-- Table structure for table `student_profiles`
--

CREATE TABLE `student_profiles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `roll_number` varchar(255) NOT NULL,
  `gr_number` varchar(255) NOT NULL,
  `course` varchar(255) DEFAULT NULL,
  `school` varchar(255) DEFAULT NULL,
  `student_type` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `student_profiles`
--

INSERT INTO `student_profiles` (`id`, `user_id`, `phone_number`, `roll_number`, `gr_number`, `course`, `school`, `student_type`, `created_at`, `updated_at`) VALUES
(1, 4, '7986490185', '123456', '876345', 'B.Tech CSE', 'School Of Engineering & Technology', 'Hostel', '2026-08-11 23:53:48', '2026-08-11 23:53:48'),
(2, 5, '9888408618', '232343', '343231', 'B.Pharmacy', 'School Of Pharmaceutical Sciences', '', '2026-08-11 23:53:49', '2026-08-11 23:53:49');

-- --------------------------------------------------------

--
-- Table structure for table `sub_categories`
--

CREATE TABLE `sub_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sub_categories`
--

INSERT INTO `sub_categories` (`id`, `category_id`, `name`, `created_at`, `updated_at`) VALUES
(1, 1, 'Electrical', '2026-08-11 04:02:42', '2026-08-11 04:02:42'),
(2, 1, 'Air-condition', '2026-08-11 04:02:42', '2026-08-11 04:02:42'),
(3, 1, 'Civil', '2026-08-11 04:02:42', '2026-08-11 04:02:42'),
(4, 1, 'Food', '2026-08-11 04:02:42', '2026-08-11 04:02:42'),
(5, 1, 'Wi-Fi', '2026-08-11 04:02:42', '2026-08-11 04:02:42'),
(6, 1, 'Plumbing', '2026-08-11 04:02:42', '2026-08-11 04:02:42'),
(7, 1, 'Housekeeping', '2026-08-11 04:02:42', '2026-08-11 04:02:42'),
(8, 2, 'Teaching', '2026-08-11 04:02:42', '2026-08-11 04:02:42'),
(9, 2, 'Attendance', '2026-08-11 04:02:42', '2026-08-11 04:02:42'),
(10, 2, 'Results', '2026-08-11 04:02:42', '2026-08-11 04:02:42'),
(11, 2, 'Placement', '2026-08-11 04:02:42', '2026-08-11 04:02:42'),
(12, 2, 'Training & Internship', '2026-08-11 04:02:42', '2026-08-11 04:02:42'),
(13, 2, 'Labs', '2026-08-11 04:02:42', '2026-08-11 04:02:42'),
(14, 3, 'Grounds', '2026-08-11 04:02:42', '2026-08-11 04:02:42'),
(15, 3, 'Gym', '2026-08-11 04:02:42', '2026-08-11 04:02:42'),
(16, 4, 'Food outlets', '2026-08-11 04:02:42', '2026-08-11 04:02:42'),
(17, 4, 'Parking', '2026-08-11 04:02:42', '2026-08-11 04:02:42'),
(18, 4, 'Housekeeping', '2026-08-11 04:02:42', '2026-08-11 04:02:42'),
(19, 4, 'Security', '2026-08-11 04:02:42', '2026-08-11 04:02:42'),
(20, 5, 'Change of Route', '2026-08-11 04:02:42', '2026-08-11 04:02:42'),
(21, 5, 'Bus Pass', '2026-08-11 04:02:42', '2026-08-11 04:02:42'),
(22, 5, 'Others', '2026-08-11 04:02:42', '2026-08-11 04:02:42'),
(23, 7, 'Scholarship', '2026-08-11 04:02:42', '2026-08-11 04:02:42'),
(24, 7, 'Late charges', '2026-08-11 04:02:42', '2026-08-11 04:02:42');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` enum('admin','student','employee') NOT NULL DEFAULT 'student',
  `status` enum('active','pending','suspended') NOT NULL DEFAULT 'active',
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'System Admin', 'complaints@cgcuniversity.in', NULL, '$2y$12$1g5kPao0FSlDio0JD/6b5uCrUf20oK0XiRZ3t2mh2HcUgLcFTMgcy', 'admin', 'active', NULL, '2026-08-11 04:02:42', '2026-08-11 04:02:42'),
(4, 'Pankaj Kumar R', 'pankaj.j2564@cgcuniversity.in', NULL, '$2y$12$uyunN9smM.8maVs7paw2/uvW4n8Yt9nyaRC9GWWoghR1qVS6gJ9v6', 'student', 'active', NULL, '2026-08-11 23:53:48', '2026-08-18 22:27:12'),
(5, 'Varun Sharma', 'varun.j3754@cgcuniversity.in', NULL, '$2y$12$mFoLJ1BRV181fg9E76wbH.78tn3jFRNO8CmCoL86a6ji4PkRM.maS', 'student', 'active', NULL, '2026-08-11 23:53:49', '2026-08-11 23:53:49'),
(6, 'Mr. Chain Singh', 'gm.digital@cgcuniversity.in', NULL, '$2y$12$w7fICbobmbdrukANMPz2DeprdWL0.M/3ZxTtcHxxcQ/XxOp3u2xpG', 'employee', 'active', NULL, '2026-08-12 00:13:03', '2026-08-12 00:13:03'),
(7, 'Yugal Sharma', 'dgm.digital@cgcuniversity.in', NULL, '$2y$12$ef6M7SUDdIOgimRLRETXnehiatdAr4TslMFdj2lCm1VvXKr8cCAEe', 'employee', 'active', NULL, '2026-08-12 00:13:03', '2026-08-12 00:13:03');

-- --------------------------------------------------------

--
-- Table structure for table `verification_codes`
--

CREATE TABLE `verification_codes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `identifier` varchar(255) NOT NULL,
  `otp` varchar(255) NOT NULL,
  `expires_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `verification_codes`
--

INSERT INTO `verification_codes` (`id`, `identifier`, `otp`, `expires_at`, `created_at`, `updated_at`) VALUES
(32, 'dgm.digital@cgcuniversity.in', '$2y$12$/A4J32BMvdMBaA0zw4CcfekYID1JZ3Hxn2L/LMRIdddH2da6exRYG', '2026-08-19 00:28:04', '2026-08-19 00:18:04', '2026-08-19 00:18:04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `categories_name_index` (`name`);

--
-- Indexes for table `complaints`
--
ALTER TABLE `complaints`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `complaints_ticket_number_unique` (`ticket_number`),
  ADD KEY `complaints_category_id_foreign` (`category_id`),
  ADD KEY `complaints_sub_category_id_foreign` (`sub_category_id`),
  ADD KEY `complaints_ticket_number_index` (`ticket_number`),
  ADD KEY `complaints_user_id_index` (`user_id`),
  ADD KEY `complaints_status_index` (`status`),
  ADD KEY `complaints_assigned_to_index` (`assigned_to`);

--
-- Indexes for table `employee_profiles`
--
ALTER TABLE `employee_profiles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `employee_profiles_employee_code_unique` (`employee_code`),
  ADD KEY `employee_profiles_user_id_foreign` (`user_id`),
  ADD KEY `employee_profiles_employee_code_index` (`employee_code`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `student_profiles`
--
ALTER TABLE `student_profiles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `student_profiles_roll_number_unique` (`roll_number`),
  ADD UNIQUE KEY `student_profiles_gr_number_unique` (`gr_number`),
  ADD KEY `student_profiles_user_id_foreign` (`user_id`),
  ADD KEY `student_profiles_roll_number_index` (`roll_number`),
  ADD KEY `student_profiles_gr_number_index` (`gr_number`);

--
-- Indexes for table `sub_categories`
--
ALTER TABLE `sub_categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sub_categories_category_id_index` (`category_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_role_index` (`role`),
  ADD KEY `users_email_index` (`email`);

--
-- Indexes for table `verification_codes`
--
ALTER TABLE `verification_codes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `complaints`
--
ALTER TABLE `complaints`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `employee_profiles`
--
ALTER TABLE `employee_profiles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `student_profiles`
--
ALTER TABLE `student_profiles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `sub_categories`
--
ALTER TABLE `sub_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `verification_codes`
--
ALTER TABLE `verification_codes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `complaints`
--
ALTER TABLE `complaints`
  ADD CONSTRAINT `complaints_assigned_to_foreign` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `complaints_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `complaints_sub_category_id_foreign` FOREIGN KEY (`sub_category_id`) REFERENCES `sub_categories` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `complaints_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `employee_profiles`
--
ALTER TABLE `employee_profiles`
  ADD CONSTRAINT `employee_profiles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `student_profiles`
--
ALTER TABLE `student_profiles`
  ADD CONSTRAINT `student_profiles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `sub_categories`
--
ALTER TABLE `sub_categories`
  ADD CONSTRAINT `sub_categories_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
